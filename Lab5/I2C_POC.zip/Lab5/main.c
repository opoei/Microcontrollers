//Lab5
//Main File for the Mega128
                            
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>
#include "lcd_functions.h"
#include "uart_functions.h"

void spi_init(void){
    DDRB |=  0x07;  //Turn on SS, MOSI, SCLK
    //mstr mode, sck=clk/2, cycle 1/2 phase, low polarity, MSB 1st, no interrupts 
    SPCR=(1<<SPE) | (1<<MSTR); //enable SPI, clk low initially, rising edge sample
    SPSR=(1<<SPI2X); //SPI at 2x speed (8 MHz)  
}

int main(void){
	spi_init();      //initalize SPI 
	lcd_init();      //initalize LCD 
	uart_init();
	clear_display(); //manually clear LCD display 
	cursor_off();    //keep LCD cursor off
	
	char remote_string[16];
	while(1)
	{ 
		clear_display();
		uart_putc('a'); //request data from mega48
		for(int i = 0; i<16; i++)
		{
			remote_string[i] = uart_getc();
		}
		string2lcd(remote_string);
		cursor_home();
	} 
} 

